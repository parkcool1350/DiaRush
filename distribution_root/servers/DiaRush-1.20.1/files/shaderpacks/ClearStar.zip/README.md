# ClearStar Shader
경량화 및 물 렌더링에 초점을 맞춘 고성능 마인크래프트 쉐이더 (MakeUp Ultra Fast 포크 버전).

## Version: 1.0

### Fabric + Iris Shaders 환경 전용 (Optifine 미지원/미테스트)
타겟 버전: 마인크래프트 1.20.1 ~ 1.21.1

## 주요 기능
* 성능 최적화를 유지하면서 향상된 품질의 물 렌더링 (파도 노멀, 반사, 수중 안개 등)
* 깔끔하게 100% 번역된 한국어 설정 메뉴 지원
* 그림자, 구름, 블룸, 안개 등 다양한 옵션 제공
* 기존 MakeUp의 다양한 Color Scheme 프레셋 지원

## 기반 코드 정보
이 쉐이더는 뛰어난 최적화로 유명한 [MakeUp - Ultra Fast](https://github.com/javiergcim/MakeUpUltraFast) 쉐이더를 기반으로 제작되었습니다.
Original Shader Author: javiergcim
