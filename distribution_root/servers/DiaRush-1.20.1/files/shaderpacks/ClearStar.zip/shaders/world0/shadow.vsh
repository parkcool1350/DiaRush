#version 120
/* MakeUp - shadow.fsh
Render: Shadowmap

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define SHADOW_SHADER

#include "/common/shadow_vertex.glsl"
